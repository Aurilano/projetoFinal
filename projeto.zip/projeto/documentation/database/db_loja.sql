-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 18-Jan-2022 às 03:41
-- Versão do servidor: 10.4.22-MariaDB
-- versão do PHP: 8.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `db_loja`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_carriers`
--

CREATE TABLE `tb_carriers` (
  `id_carriers` int(11) NOT NULL,
  `carriers_name` varchar(50) NOT NULL,
  `carriers_cnpj` varchar(20) NOT NULL,
  `carriers_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_carriers`
--

INSERT INTO `tb_carriers` (`id_carriers`, `carriers_name`, `carriers_cnpj`, `carriers_created`) VALUES
(3, 'Transportadora Asa verde', '09.857.453/0001-03', '2022-01-18 02:18:05'),
(4, 'Translog', '28.468.851/0001-82', '2022-01-18 02:18:21');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_citys`
--

CREATE TABLE `tb_citys` (
  `id_citys` int(11) NOT NULL,
  `citys_name` varchar(30) NOT NULL,
  `citys_uf` char(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_citys`
--

INSERT INTO `tb_citys` (`id_citys`, `citys_name`, `citys_uf`) VALUES
(1, 'Fortaleza', 'Ce'),
(2, 'Itapipoca', 'Ce'),
(3, 'Itapajé', 'Ce'),
(4, 'Sobral', 'Ce'),
(5, 'Baturité', 'Ce'),
(6, 'Juazeiro', 'Ce'),
(7, 'Crato', 'Ce'),
(8, 'Caucaia', 'Ce'),
(9, 'Paracuru', 'Ce');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_products`
--

CREATE TABLE `tb_products` (
  `id_product` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_category` varchar(20) NOT NULL,
  `product_stock` int(7) NOT NULL,
  `product_provider` varchar(30) NOT NULL,
  `product_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_products`
--

INSERT INTO `tb_products` (`id_product`, `product_name`, `product_category`, `product_stock`, `product_provider`, `product_created`) VALUES
(1, 'Arroz Camil 1kg', 'Cereais', 50, 'FORNECEDOR 01 LTDA', '2022-01-15 12:43:15'),
(3, 'Açucar Cristal', 'Cereais', 150, 'FORNECEDOR 01 LTDA', '2022-01-15 13:03:43'),
(4, 'Feijão Carioca', 'Cereais', 100, 'FORNECEDOR 01 LTDA', '2022-01-16 02:00:31'),
(5, 'Farinha  Branca Kg', 'Cereais', 80, 'FORNECEDOR 01 LTDA', '2022-01-16 03:10:50');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_providers`
--

CREATE TABLE `tb_providers` (
  `id_provider` int(11) NOT NULL,
  `provider_name` varchar(50) NOT NULL,
  `provider_cnpj` varchar(20) NOT NULL,
  `provider_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_providers`
--

INSERT INTO `tb_providers` (`id_provider`, `provider_name`, `provider_cnpj`, `provider_created`) VALUES
(2, 'Center Box', '01.089.418/0001-46', '2022-01-18 00:58:25'),
(3, 'Atacadão CIA', '01.089.418/0001-80', '2022-01-18 01:13:27');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_users`
--

CREATE TABLE `tb_users` (
  `id_user` int(3) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_type` varchar(30) NOT NULL,
  `user_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_users`
--

INSERT INTO `tb_users` (`id_user`, `user_name`, `user_email`, `user_password`, `user_type`, `user_created`) VALUES
(1, 'Aurilano de Sousa Pinheiro', 'aurilano@email.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'Admin', '2022-01-11 21:26:19'),
(2, 'Sophia Feitosa Pinheiro', 'sophia@email.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'Admin', '2022-01-11 21:31:58');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tb_carriers`
--
ALTER TABLE `tb_carriers`
  ADD PRIMARY KEY (`id_carriers`);

--
-- Índices para tabela `tb_citys`
--
ALTER TABLE `tb_citys`
  ADD PRIMARY KEY (`id_citys`);

--
-- Índices para tabela `tb_products`
--
ALTER TABLE `tb_products`
  ADD PRIMARY KEY (`id_product`);

--
-- Índices para tabela `tb_providers`
--
ALTER TABLE `tb_providers`
  ADD PRIMARY KEY (`id_provider`);

--
-- Índices para tabela `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_carriers`
--
ALTER TABLE `tb_carriers`
  MODIFY `id_carriers` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tb_citys`
--
ALTER TABLE `tb_citys`
  MODIFY `id_citys` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `tb_products`
--
ALTER TABLE `tb_products`
  MODIFY `id_product` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `tb_providers`
--
ALTER TABLE `tb_providers`
  MODIFY `id_provider` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `tb_users`
--
ALTER TABLE `tb_users`
  MODIFY `id_user` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
