<hr>
<h3>
	Adicionar Fornecedor
</h3>
<hr>
<div class="container">
		<form action="<?=$GLOBALS['index'];?>/controller/Provider.php" method="POST">
			<div class="row">
			  
			  <div class="mb-3 col-md-6">
			    <label for="exampleInputPassword1" class="form-label">Nome do Fornecedor</label>
			    <input type="text" name="provider_name" class="form-control" id="exampleInputPassword1">
			  </div>

			  <div class="mb-3 col-md-6">
			    <label for="exampleInputPassword1" class="form-label">CNPJ</label>
			    <input type="text" name="provider_cnpj" class="form-control" id="exampleInputPassword1">
			  </div>

			  <input type="hidden" name="action" value="add">
			  <div class="col-md-4"><button type="submit" class="btn btn-primary">Cadastrar Fornecedor</button></div>
			</div>	
		</form>
</div>