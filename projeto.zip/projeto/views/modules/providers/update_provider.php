<hr>
<h3>Atualizar Fornecedor</h3>
<hr>
<div class="container">
		<form action="<?=$GLOBALS['index'];?>/controller/Provider.php" method="POST">
			<div class="row">
			  
			  <div class="mb-3 col-md-6">
			    <label for="exampleInputPassword1" class="form-label">Nome do Fornecedor</label>
			    <input type="text" value="<?=$provider[0]['provider_name'];?>" name="provider_name" class="form-control" id="exampleInputPassword1">
			  </div>

			  <div class="mb-3 col-md-6">
			    <label for="exampleInputPassword1" class="form-label">CNPJ</label>
			    <input type="text" value="<?=$provider[0]['provider_cnpj'];?>" name="provider_cnpj" class="form-control" id="exampleInputPassword1">
			  </div>

			  <input type="hidden" name="action" value="edit">
			  <input type="hidden" name="id_provider" value="<?=$provider[0]['id_provider'];?>">
			  <div class="col-md-4"><button type="submit" class="btn btn-warning">Atualizar Produto</button></div>
			</div>	
		</form>
</div>