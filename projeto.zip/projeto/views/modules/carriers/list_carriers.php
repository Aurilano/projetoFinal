<hr>
<h3>
	Lista de Transportadora | <a href="?op=add_carrier" class="btn btn-primary btn-sm"> Adicionar </a>
</h3>
<hr>
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Nome</th>
              <th scope="col">CNPJ</th>
              <th scope="col">Data do Cadastro</th>
              <th scope="col">Ações</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($carriers as $t): ?>	
            	<tr>
	              <td><?=$t['id_carriers'];?></td>
	              <td><?=$t['carriers_name'];?></td>
	              <td><?=$t['carriers_cnpj'];?></td>
	              <td><?=$t['carriers_created'];?></td>
	              <td>
	              	<a href="?op=update_carrier&id=<?=$t['id_carriers'];?>" class="btn btn-warning btn-sm"> <i class="fa fa-edit"></i></a>

	              	<button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#transportadora-<?=$t['id_carriers'];?>">
	              		<i class="fa fa-trash"></i>
	              	</button>

					<!-- Modal -->
					<div class="modal fade" id="transportadora-<?=$t['id_carriers'];?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
					  <div class="modal-dialog">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="exampleModalLabel">Excluir <?=$t['carriers_name'];?></h5>
					        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					      </div>
					      <form action="<?=$GLOBALS['index'];?>/controller/Carrier.php" method="POST">
						      <div class="modal-body">
						        <h3> Tem certeza ue deseja excluir? Essa operação nao podera ser desfeita! </h3>
						        <input type="hidden" name="id_carriers" value="<?=$t['id_carriers'];?>">
						        <input type="hidden" name="action" value="delete">
						      </div>
						      <div class="modal-footer">
						        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
						        <button type="submit" class="btn btn-primary">Continuar</button>
						      </div>
					  	  </form>
					    </div>
					  </div>
					</div>


	              </td>
            	</tr>
	        <?php endforeach; ?>
            
          </tbody>
        </table>
      </div>