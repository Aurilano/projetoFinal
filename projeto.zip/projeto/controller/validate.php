<?php  
	
	function validate_options(){

		if(!isset($_GET['op'])){
			return false;
		}

		include_once $GLOBALS['path']."/models/classes/Connect.class.php";
		include_once $GLOBALS['path']."/models/classes/Manager.class.php";

		switch($_GET['op']){

			case 'users':
				$manager = new Manager;
				$users = $manager->select_common("tb_users", null, null, null);
				var_dump($users);	
			break;


			##############################################################################
			##############################PRODUTO########################################
			case 'list_products':
				$manager = new Manager;
				$products = $manager->select_common("tb_products", null, null, null);
				include_once $GLOBALS['path']."/views/modules/products/list_products.php";
			break;

			case 'add_product':
				include_once $GLOBALS['path']."/views/modules/products/add_product.php";
			break;

			case 'update_product':
				$manager = new Manager;
				$product = $manager->select_common("tb_products", null, ["id_product"=>$_GET['id']], null);
				include_once $GLOBALS['path']."/views/modules/products/update_product.php";
			break;

			##############################################################################
			##############################FORNECEDOR########################################

			case 'list_providers':
				$manager = new Manager;
				$providers = $manager->select_common("tb_providers", null, null, null);
				include_once $GLOBALS['path']."/views/modules/providers/list_providers.php";
			break;

			case 'add_provider':
				include_once $GLOBALS['path']."/views/modules/providers/add_provider.php";
			break;

			case 'update_provider':
				$manager = new Manager;
				$provider = $manager->select_common("tb_providers", null, ["id_provider"=>$_GET['id']], null);
				include_once $GLOBALS['path']."/views/modules/providers/update_provider.php";
			break;

			##############################################################################
			##############################Transportadora##################################	

			case 'list_carriers':
				$manager = new Manager;
				$carriers = $manager->select_common("tb_carriers", null, null, null);
				include_once $GLOBALS['path']."/views/modules/carriers/list_carriers.php";
			break;

			case 'add_carrier':
				include_once $GLOBALS['path']."/views/modules/carriers/add_carrier.php";
			break;

			case 'update_carrier':
				$manager = new Manager;
				$carrier = $manager->select_common("tb_carriers", null, ["id_carriers"=>$_GET['id']], null);
				include_once $GLOBALS['path']."/views/modules/carriers/update_carrier.php";
			break;

		}



	}


?>