<?php  

    session_start();

    if(isset($_SESSION[md5("user_data")])){
        header("location: admin.php");
    }

?>


<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<html>
  <head>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <link rel="stylesheet" href="views/assets/css/login.css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <!------ Include the above in your HEAD tag ---------->
  </head>
    <body id="LoginForm">
        <div class="container">
            <div class="login-form">
                <div class="main-div">
                    <div class="panel">
                        <h3>Login</h3>
                        <h4><p>usuário: aurilano@email.com</p></h4>
                        <p>Senha: 123456</p>
                    </div>
                    <form id="Login" method="POST" action="controller/login.php">
                        <div class="form-group">
                            <input type="email" class="form-control" name="email" id="inputEmail" placeholder="Email Address">
                        </div>

                        <div class="form-group">
                            <input type="password" class="form-control"  name="password" id="inputPassword" placeholder="Password">
                        </div>

                        <button type="submit" class="btn btn-primary">Login</button>
                    </form>
                </div>
                <!--<p class="botto-text"> Designed by Sunil Rajput</p> -->
            </div>
        </div>
    </body>
</html>